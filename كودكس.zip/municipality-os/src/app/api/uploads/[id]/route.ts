import { Role } from "@prisma/client";
import { getCurrentUser, isStaffRole } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { resolveMunicipality } from "@/lib/tenant";
export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser(); if (!user) return new Response("غير مصرح", { status: 401 });
  const { id } = await params; const municipality = await resolveMunicipality(request);
  if (!municipality || (user.role !== Role.SUPER_ADMIN && user.municipalityId !== municipality.id)) return new Response("غير مصرح", { status: 403 });
  const file = await prisma.upload.findFirst({ where: { id, municipalityId: municipality.id, ...(isStaffRole(user.role) ? {} : { userId: user.id }) }, select: { data: true, mimeType: true, fileName: true } });
  if (!file) return new Response("غير موجود", { status: 404 });
  return new Response(file.data, { headers: { "Content-Type": file.mimeType, "Content-Disposition": `inline; filename="${encodeURIComponent(file.fileName)}"`, "Cache-Control": "private, max-age=3600", "X-Content-Type-Options": "nosniff" } });
}
