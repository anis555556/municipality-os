import { Role } from "@prisma/client";
import { requireUser } from "@/lib/auth";
import { apiError, json } from "@/lib/http";
import { prisma } from "@/lib/prisma";
import { enforceRateLimit } from "@/lib/rate-limit";
import { requireTenant } from "@/lib/tenant";
const allowedMime = new Set(["image/jpeg", "image/png", "image/webp"]);
export async function POST(request: Request) {
  try {
    const user = await requireUser([Role.CITIZEN, Role.STAFF, Role.EDITOR, Role.ADMIN, Role.SUPER_ADMIN]);
    const declaredLength = Number(request.headers.get("content-length") || 0);
    if (declaredLength > 5.5 * 1024 * 1024) return json({ error: "تجاوز حجم الصورة الحد المسموح" }, 413);
    await enforceRateLimit(`upload:${user.id}`, 12, 60 * 60_000); const { municipality } = await requireTenant(request, true);
    const form = await request.formData(); const file = form.get("file");
    if (!(file instanceof File)) return json({ error: "اختر صورة للرفع" }, 400);
    if (!allowedMime.has(file.type)) return json({ error: "الصيغ المقبولة JPG أو PNG أو WebP" }, 415);
    if (file.size < 1 || file.size > 5 * 1024 * 1024) return json({ error: "يجب ألا يتجاوز حجم الصورة 5 ميغابايت" }, 413);
    const bytes = Buffer.from(await file.arrayBuffer());
    const stored = await prisma.upload.create({ data: { municipalityId: municipality.id, userId: user.id, fileName: file.name.replace(/[\\/\r\n]/g, "").slice(0, 160), mimeType: file.type, sizeBytes: bytes.length, data: bytes } });
    return json({ id: stored.id, url: `/api/uploads/${stored.id}`, fileName: stored.fileName, sizeBytes: stored.sizeBytes }, 201);
  } catch (error) { return apiError(error); }
}
